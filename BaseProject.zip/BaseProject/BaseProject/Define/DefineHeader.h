//
//  DefineHeader.h
//  BaseProject
//
//  Created by admin on 2018/11/27.
//  Copyright © 2018 JY. All rights reserved.
//

#ifndef DefineHeader_h
#define DefineHeader_h

#define JYHost @""

#endif /* DefineHeader_h */
