//
//  JYModel.h
//  BaseProject
//
//  Created by admin on 2018/11/27.
//  Copyright © 2018 JY. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JYModel : NSObject

@end

NS_ASSUME_NONNULL_END
