//
//  JYModel.m
//  BaseProject
//
//  Created by admin on 2018/11/27.
//  Copyright © 2018 JY. All rights reserved.
//

#import "JYModel.h"

@implementation JYModel

@end
